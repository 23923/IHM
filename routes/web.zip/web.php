<?php

use Illuminate\Support\Facades\Route;


Route::get('/course', function () {
    return view('course');
});
Route::get('/index', function () {
    return view('index');
});
Route::get('/', function () {
    return view('about');
});
Route::get('/list', function () {
    return view('adminLayout/categories/list');
});


